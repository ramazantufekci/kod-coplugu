jQuery(document).ready(function(){
    
    jQuery('#ssl_from_date,#ssl_to_date').datepicker({ dateFormat: 'yy-mm-dd' });
    
    jQuery('.wp-ssl-report a.next-page').on( "click", function() {
        if(jQuery('#ssl_from_date').length > 0){
            jQuery(this).attr('href',jQuery(this).attr('href') + '&ssl_from_date='+jQuery('#ssl_from_date').val()+'&ssl_to_date='+jQuery('#ssl_to_date').val());
        }
    });
    
    jQuery('.wp-ssl-report th.sortable').on( "click", function() {
        if(jQuery('#ssl_from_date').length > 0){
            jQuery('.wp-ssl-report th.sortable a').attr('href',jQuery('.wp-ssl-report th.sortable a').attr('href') + '&ssl_from_date='+jQuery('#ssl_from_date').val()+'&ssl_to_date='+jQuery('#ssl_to_date').val());
        }
    });

    jQuery('#ssl_status').on( "click", function() {
        var currentUrl = jQuery(this).find('a').attr('href');
        var url = new URL(currentUrl);
        url.searchParams.set("orderby", "order_status"); // setting your param
        var newUrl = url.href;
        jQuery('.wp-ssl-report th.sortable a').attr('href',newUrl);
        window.location.replace(newUrl);
    });

    jQuery('#store_order_id').on( "click", function() {
        var currentUrl = jQuery(this).find('a').attr('href');
        var url = new URL(currentUrl);
        url.searchParams.set("orderby", "ssl_order_id"); // setting your param
        var newUrl = url.href;
        jQuery('.wp-ssl-report th.sortable a').attr('href',newUrl);
        window.location.replace(newUrl);
    });

    jQuery('#order_id').on( "click", function() {
        var currentUrl = jQuery(this).find('a').attr('href');
        var url = new URL(currentUrl);
        url.searchParams.set("orderby", "order_id"); // setting your param
        var newUrl = url.href;
        jQuery('.wp-ssl-report th.sortable a').attr('href',newUrl);
        window.location.replace(newUrl);
    });

    jQuery('#refund_status').on( "click", function() {
        var currentUrl = jQuery(this).find('a').attr('href');
        var url = new URL(currentUrl);
        url.searchParams.set("orderby", "refund_status"); // setting your param
        var newUrl = url.href;
        jQuery('.wp-ssl-report th.sortable a').attr('href',newUrl);
        window.location.replace(newUrl);
    });

    jQuery('#cancellation_date').on( "click", function() {
        var currentUrl = jQuery(this).find('a').attr('href');
        var url = new URL(currentUrl);
        url.searchParams.set("orderby", "date_created"); // setting your param
        var newUrl = url.href;
        jQuery('.wp-ssl-report th.sortable a').attr('href',newUrl);
        window.location.replace(newUrl);
    });
    
    jQuery('.wp-ssl-report #btn_date_range').on("click",function(){
        jQuery('.wp-ssl-report #current-page-selector').val('1');
    });
    
    /* product pricing update */
    jQuery('.wp_ssl_product_pricing #wp_sslstore_apply_margin').on("change",function(){
        if(jQuery(this).is(':checked') == true){
            jQuery('.wp_ssl_product_pricing input[name="margin_percentage"], .wp_ssl_product_pricing input[name="btn_apply_margin"]').attr('disabled',false);
        }
        else{
            jQuery('.wp_ssl_product_pricing input[name="margin_percentage"], .wp_ssl_product_pricing input[name="btn_apply_margin"]').attr('disabled',true);
        }
    });
    
    jQuery('.wp_ssl_product_pricing input[name="btn_apply_margin"]').on("click",function(){
        if(isNaN(jQuery('.wp_ssl_product_pricing input[name="margin_percentage"]').val())){
            alert("Please enter valid profit percentage.");
            return false;
        }
        
        if(jQuery('input[name="pid[]"]:checked').length == 0){
            alert("Please select atleast one product.");
            return false;
        }
        var per = jQuery('.wp_ssl_product_pricing input[name="margin_percentage"]').val();
        jQuery( 'input[name="pid[]"]:checked' ).each(function() {
            jQuery('input[data-pid="'+jQuery(this).val()+'"]').each(function(){
                var p = jQuery(this).data('ssl-price');
                p = p + (p * per/100);
                jQuery(this).val(p.toFixed(2));
            });
        });
        alert('Pricing is applied for preview only, Please press "Update Price" button to update.');
    });
    
    
    /* product pricing update */
    
    
    /*import order */
    
    jQuery('.wp-ssl-import-order input[name="wc_order_type"]').on('change', function(){
        if(jQuery(this).val() == 'new'){
            jQuery('div.new-ord').show();
            jQuery('div.existing-ord').hide();
        }
        else if(jQuery(this).val() == 'existing'){
            jQuery('div.new-ord').hide();
            jQuery('div.existing-ord').show();
        }
        
    });
    
    /*import order*/
    
    jQuery( 'button.wp-sslstore-btn-cancel' ).click( function( e ) {
		
        var id   = jQuery( this ).attr( 'data-id' );

        var data = {
                action: 'admin_cancel_order',
                store_order_id: id
        }
        
        jQuery( this ).text( 'Trying to cancel order' ).attr('disabled', true);

        jQuery.ajax({
            async : true,
            url: wp_sslstore_admin.ajaxurl,
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'admin_cancel_order',
                store_order_id: id
            },
            success: function( result ){
                if(result.success == true){
                    alert(wp_sslstore_admin.success_cancel_msg);
                }
                else{
                    alert(result.error);
                }
                document.location.reload();
            }
        });
        e.preventDefault();
    });

    /* Prevent Enter to download CSV */
    jQuery(".wp-ssl-report").keypress(function(e) {
        console.log(this);
        //Enter key
        if (e.which == 13) {
            return false;
        }
    });

    jQuery(".wp-ssl-import-order").keypress(function(e) {
        console.log(this);
        //Enter key
        if (e.which == 13) {
            return false;
        }
    });
});