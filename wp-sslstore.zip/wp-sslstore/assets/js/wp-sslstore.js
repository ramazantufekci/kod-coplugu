jQuery('[name=quantity],[name=variation_id]').change(function(){
    ssl_display_dynamic_price();
});

function ssl_display_dynamic_price() {
    if(jQuery('[name=quantity]').val() != '' && jQuery('[name=variation_id]').val()){
        var product_variations_data = jQuery.parseJSON(jQuery("form.variations_form.cart").attr('data-product_variations'));
        for(i=0; i < product_variations_data.length; i++){
            if(product_variations_data[i].variation_id == jQuery('[name=variation_id]').val()){
                var price_html = product_variations_data[i].price_html;
                var sale_price = product_variations_data[i].display_price;
                var regular_price = product_variations_data[i].display_regular_price;
                var final_sale_price = (sale_price * jQuery('[name=quantity]').val()).toFixed(2);
                var final_regular_price = (regular_price *  jQuery('[name=quantity]').val()).toFixed(2);
                price_html = price_html.replace(sale_price.toFixed(2), final_sale_price);
                price_html = price_html.replace(regular_price.toFixed(2), final_regular_price);

                jQuery('.woocommerce-variation-price').html(price_html);

            }
        }
    }
}

jQuery('[data-attribute_name=attribute_additional-domains]').change(function(){
    if (jQuery("body").find('select[data-attribute_name="attribute_additional-wildcard-domains"]')) {
        for(var i = 0; i <= 30; i++){
            var op_val = 30 - jQuery('[data-attribute_name=attribute_additional-domains]').val();
            if(i > op_val) {
                jQuery("select[data-attribute_name='attribute_additional-wildcard-domains'] option[value=" + i + "]").hide();
            }else{
                jQuery("select[data-attribute_name='attribute_additional-wildcard-domains'] option[value=" + i + "]").show();
            }
        }
    }
});

jQuery('[data-attribute_name=attribute_additional-wildcard-domains]').change(function(){
    if (jQuery("body").find('select[data-attribute_name="attribute_additional-domains"]')) {
        for(var i = 0; i <= 30; i++){
            var op_val = 30 - jQuery('[data-attribute_name=attribute_additional-wildcard-domains]').val();
            if(i > op_val) {
                jQuery("select[data-attribute_name='attribute_additional-domains'] option[value=" + i + "]").hide();
            }else{
                jQuery("select[data-attribute_name='attribute_additional-domains'] option[value=" + i + "]").show();
            }
        }
    }
});
