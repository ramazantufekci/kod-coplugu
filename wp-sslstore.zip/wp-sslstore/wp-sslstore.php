<?php

/**
* Plugin Name: WP SSLStore
* Plugin URI: thesslstore.com
* Description: Online ssl store.
* Version: 2.3.1
* Author: The SSL Store
* Author URI: thesslstore.com
* Text Domain: wp-sslstore
*/
if ( ! defined( 'ABSPATH' ) ){
    exit; // Exit if accessed directly
}

if ( ! class_exists( 'WP_SSLStore' ) ) :

class WP_SSLStore
{

    /**
     * @var string
     */
    public $version = '2.3.1';

    /**
     * @var WPSSL The single instance of the class
     */
    protected static $_instance = null;


    /**
     * Main WPSSL Instance
     *
     * Ensures only one instance of WPSSL is loaded or can be loaded.
     * @static
     * @return WPSSL - Main instance
     */

    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * WPSSL Constructor.
     */
    public function __construct() {
        if(!in_array('woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' )))){
            die('Please intsall and activate WooCommerce plugin');
        }
        $this->define_constants();
        $this->includes();
        $this->init_hooks();
        $this->default_options();
       // do_action( 'wpssl_loaded' );
    }

    /**
     * Define WPSSL Constants
     */
    private function define_constants() {

        $upload_dir = wp_upload_dir();

        $this->define( 'WP_SSLSTORE_PLUGIN_PATH', untrailingslashit(plugin_dir_path(__FILE__)));
        $this->define( 'WP_SSLSTORE_PLUGIN_URL', untrailingslashit(plugin_dir_url(__FILE__)));
        $this->define( 'WP_SSLSTORE_PLUGIN_FILE', __FILE__ );
        $this->define( 'WP_SSLSTORE_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
        $this->define( 'WP_SSLSTORE_VERSION', $this->version );
        $this->define( 'WP_SSLSTOREL_VERSION', $this->version );
        $this->define( 'WP_SSLSTORE_LOG_DIR', $upload_dir['basedir'] . '/wp-sslstore-logs/' );
        $this->define( 'ALLOW_UNFILTERED_UPLOADS', true );

        if ( ! defined( 'WP_SSLSTORE_ASSESTS_URL' ) ) {
            define('WP_SSLSTORE_ASSESTS_URL', plugin_dir_url(__FILE__).'assets/');
        }
    }

    /**
     * Define constant if not already set
     * @param  string $name
     * @param  string|bool $value
     */
    private function define( $name, $value ) {
        if ( ! defined( $name ) ) {
            define( $name, $value );
        }
    }

    /**
     * Include required core files used in admin and on the frontend.
     */
    public function includes() {
        include_once('includes/wp-sslstore-languages.php');
        include_once('includes/admin/wp-sslstore-admin-menu.php'); //Admin Menu
        if(is_admin())
        {
            include_once('includes/admin/export-report-to-csv.php');
        }
        include_once( 'includes/wp-sslstore-install.php' ); //Activation call
        include_once( 'api/sslstore.php' ); //REST API
        include_once('includes/wp-sslstore-utility.php');
        include_once('includes/wp-sslstore-woocommerce.php');
        include_once('includes/wp-sslstore-cron.php');
    }
    
    /**
     * Creates the options
     */
    private function default_options() {
        //check if option is already present
        //option key is plugin_abbr_op, but can be anything unique
        if(!get_option('sslstore_import_products_cron_status')) {

            add_option('sslstore_import_products_cron_status', 'stopped');
        }
    }

    /**
     * Hook into actions and filters
     * @since  2.3.1
     */
    private function init_hooks() {

        register_activation_hook( __FILE__, array( 'WP_SSLStore_Install', 'install' ));

        register_deactivation_hook (__FILE__, array('WP_SSLStore_Install','uninstall'));
        
        //call on plugin update
        add_action('plugins_loaded', array('WP_SSLStore_Install','update'));

        //add javascript to front
        add_action('wp_enqueue_scripts', array('WP_SSLStore_Install', 'enqueue_scripts'));
        
        //add javascript and css in admin side
        add_action('admin_enqueue_scripts', array('WP_SSLStore_Install', 'admin_enqueue_scripts'));

        //add script/css to admin
        add_action( 'admin_enqueue_scripts', array( 'WP_SSLStore_Admin_Menu', 'add_script_to_admin' ));

        //add menu in sidebar
        add_action( 'admin_menu', array( 'WP_SSLStore_Admin_Menu', 'admin_menu' ), 9 );

        add_action("admin_init", array('WP_SSLStore_Export_Report_To_CSV','export_to_csv'));
	    //Place an order in SSL Store when WooCommerce order is completed

        add_action( 'woocommerce_order_status_completed', array('WP_SSLStore_Woocommerce', 'place_ssl_order'), 10, 1 );

        //Delete entry when product is deleted
        add_action( 'after_delete_post', array( 'WP_SSLStore_Admin_Menu', 'delete_product_entry'),10);

        //add column in WooCommerce order list
        add_filter( 'manage_edit-shop_order_columns', array( 'WP_SSLStore_Admin_Menu', 'add_column_name_in_order_list'),10);

        //add column content value
        add_action( 'manage_shop_order_posts_custom_column', array( 'WP_SSLStore_Admin_Menu', 'add_column_content_in_order_list') );

        //add ssl details metabox in admin order detail
        add_action( 'add_meta_boxes', array( 'WP_SSLStore_Admin_Menu', 'add_admin_ssl_details_metabox'), 10 );

        //add filter for change order status from processing to complete
        add_filter( 'woocommerce_payment_complete_order_status',  array('WP_SSLStore_Woocommerce', 'wc_order_status_change'), 10, 2 );

        //add empty cart button
        add_action( 'woocommerce_cart_actions', array('WP_SSLStore_Woocommerce','add_empty_cart_button'));
        add_action( 'init', array('WP_SSLStore_Woocommerce','woocommerce_clear_cart'));
	    //add additional details like generation link in thank you and order detail page
        add_action( 'woocommerce_order_details_after_order_table', array('WP_SSLStore_Woocommerce', 'order_details'), 10, 1 );

        //add additional details like generation link in customer email
        add_action( 'woocommerce_email_after_order_table', array('WP_SSLStore_Woocommerce', 'order_details_in_email'), 10, 1 );

        // Update cart validation
        add_filter( 'woocommerce_update_cart_validation', array('WP_SSLStore_Woocommerce', 'update_cart_validation'), 1, 4 );

        //create order detail page
        add_action( 'init', array('WP_SSLStore_Woocommerce', 'add_endpoints'));
        add_filter( 'query_vars', array( 'WP_SSLStore_Woocommerce', 'add_query_vars' ), 0 );
        add_filter( 'the_title', array( 'WP_SSLStore_Woocommerce', 'ssl_order_page_title' ), 1 );

        // set content for order details page.
        add_action( 'woocommerce_account_' . WP_SSLStore_Woocommerce::$ssl_order_detail_endpoint .  '_endpoint', array( 'WP_SSLStore_Woocommerce', 'ssl_order_detail_content' ) );
        add_action( 'woocommerce_account_' . WP_SSLStore_Woocommerce::$ssl_order_cancel_endpoint .  '_endpoint', array( 'WP_SSLStore_Woocommerce', 'ssl_order_cancellation_content' ) );

        //download certificate
        add_action( 'init', array('WP_SSLStore_Woocommerce', 'ssl_certificate_download'));

        //add status for order
        add_filter( 'init', array( 'WP_SSLStore_Woocommerce', 'register_order_status' ) );
        add_filter( 'wc_order_statuses', array( 'WP_SSLStore_Woocommerce', 'add_order_status' ) );

        //hook for payment refund
        add_action( 'woocommerce_order_refunded', array('WP_SSLStore_Woocommerce', 'hook_on_order_refunded'), 10, 2 );

        //override woocommerce template (for eg. quantity input to select box)
        add_filter( 'woocommerce_locate_template', array('WP_SSLStore_Woocommerce', 'override_woocommerce_template'), 10, 3 );

        //set action for cron
        add_action('sslstore_sync_order_cron_job', array( 'WP_SSLStore_Cron', 'syn_orders'));
        add_action('sslstore_expiration_reminder_cron_job', array( 'WP_SSLStore_Cron', 'expiration_reminder'));
        add_action('sslstore_import_csv_order_cron_job', array( 'WP_SSLStore_Cron', 'place_import_csv_order'));
        add_action('sslstore_import_products', array( 'WP_SSLStore_Cron', 'import_products'));
        add_action('sslstore_sync_product_cron_job', array( 'WP_SSLStore_Cron', 'syn_product'));

        add_filter( 'cron_schedules', array( 'WP_SSLStore_Cron', 'syn_interval') );

        //set expiration reminder email
        add_filter( 'woocommerce_email_classes', array('WP_SSLStore_Woocommerce','add_expiration_reminder_email'));
        
        //admin order details page
        add_action( 'add_meta_boxes', array('WP_SSLStore_Woocommerce', 'add_metabox_shop_order'));
        
        //Update cart for purchase additional SANs
        add_action( 'woocommerce_before_calculate_totals', array('WP_SSLStore_Woocommerce', 'update_cart_price_for_purchase_sans'), 15, 1 );

        // set session for purchase SANs
        add_action( 'woocommerce_cart_loaded_from_session', array('WP_SSLStore_Woocommerce', 'detect_edit_order') );

        add_filter( 'woocommerce_cart_item_name', array('WP_SSLStore_Woocommerce', 'change_title'), 10, 3 );

        add_action( 'woocommerce_before_thankyou', array('WP_SSLStore_Woocommerce', 'change_order_title'));

        add_action( 'woocommerce_thankyou', array('WP_SSLStore_Woocommerce', 'payment_data_collect'), 10, 1 );

        add_action( 'save_post', array('WP_SSLStore_Admin_Menu', 'refund_request_process'), 1,1 );

        /* Edit variation start */
        //add js file to cart 
        add_action('wp_head', array('WP_SSLStore_Woocommerce', 'edit_variation_in_cart_js'));
        add_action('wp_head', array('WP_SSLStore_Woocommerce', 'edit_variation_in_cart_js_vars'));

        //add edit link on cart page 
        add_filter( 'woocommerce_cart_item_name', array('WP_SSLStore_Woocommerce', 'edit_variation_in_cart_product_title'), 20, 3);

        //get variation form using ajax
        add_action( 'wp_ajax_get_variation_form', array('WP_SSLStore_Woocommerce', 'edit_variation_in_cart_form' ));
        add_action( 'wp_ajax_nopriv_get_variation_form', array('WP_SSLStore_Woocommerce', 'edit_variation_in_cart_form' ));

        //update product
        add_action( 'wp_ajax_update_product_in_cart', array('WP_SSLStore_Woocommerce', 'edit_variation_in_cart_update_product_in_cart' ));
        add_action( 'wp_ajax_nopriv_update_product_in_cart', array('WP_SSLStore_Woocommerce', 'edit_variation_in_cart_update_product_in_cart' ));

        /* Edit variation end */
        
        add_filter( 'wc_product_sku_enabled', array('WP_SSLStore_Woocommerce', 'remove_product_page_skus' ));
        
        //Hide Price Range for WooCommerce Variable Products
        add_filter( 'woocommerce_format_price_range', array('WP_SSLStore_Woocommerce', 'hide_variable_product_price'), 10, 3 );

    }
}
endif;

$GLOBALS['WP_SSLStore'] = WP_SSLStore::instance();
